var students =
{
    name : 'rafay',
    age : 19,
    stu_ID : 123
}
console.log(students.name);
console.log(students.age);
console.log(students.stu_ID);

