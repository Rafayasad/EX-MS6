var fen = prompt("enter a value of ferenheit: ");
var output = (fen - 32) * 9 / 5 ;
document.write("<br />");
document.write(fen+"F to "+output+"C");
var cel = prompt("enter a value of celsius: ");
var out = cel * 9/5 + 32; 
document.write("<br />");
document.write(cel+"C to "+out+"F");
